import { Router } from "express";
import { z } from "zod";
import { getServices, createOrder, checkOrderStatus } from "../services/smmService";
import { logger } from "../lib/logger";

const router = Router();

// ─────────────────────────────────────────────────────────
// Validation schemas
// ─────────────────────────────────────────────────────────

const createOrderSchema = z.object({
  serviceId: z
    .number({ invalid_type_error: "serviceId doit être un nombre" })
    .int()
    .positive("serviceId doit être positif"),
  link: z
    .string({ required_error: "link est requis" })
    .url("link doit être une URL valide"),
  quantity: z
    .number({ invalid_type_error: "quantity doit être un nombre" })
    .int()
    .min(1, "quantity doit être au minimum 1"),
});

// ─────────────────────────────────────────────────────────
// GET /api/smm/services
// Récupère la liste des services SMM
// ─────────────────────────────────────────────────────────
router.get("/services", async (req, res) => {
  try {
    const services = await getServices();
    res.json({ success: true, data: services });
  } catch (error: any) {
    logger.error({ error: error.message }, "[SMM] Erreur getServices");
    res.status(502).json({
      success: false,
      message: "Impossible de récupérer les services SMM",
      error: error.message,
    });
  }
});

// ─────────────────────────────────────────────────────────
// POST /api/smm/order
// Crée une nouvelle commande
// Body: { serviceId, link, quantity }
// ─────────────────────────────────────────────────────────
router.post("/order", async (req, res) => {
  const validation = createOrderSchema.safeParse(req.body);

  if (!validation.success) {
    const errors = validation.error.errors.map((e) => e.message);
    res.status(400).json({ success: false, message: "Données invalides", errors });
    return;
  }

  const { serviceId, link, quantity } = validation.data;

  try {
    const result = await createOrder(serviceId, link, quantity);
    res.status(201).json({ success: true, data: result });
  } catch (error: any) {
    logger.error({ error: error.message }, "[SMM] Erreur createOrder");
    res.status(502).json({
      success: false,
      message: "Impossible de créer la commande",
      error: error.message,
    });
  }
});

// ─────────────────────────────────────────────────────────
// GET /api/smm/order/:id
// Vérifie le statut d'une commande
// ─────────────────────────────────────────────────────────
router.get("/order/:id", async (req, res) => {
  const orderId = parseInt(req.params.id, 10);

  if (isNaN(orderId) || orderId <= 0) {
    res.status(400).json({ success: false, message: "ID de commande invalide" });
    return;
  }

  try {
    const status = await checkOrderStatus(orderId);
    res.json({ success: true, data: status });
  } catch (error: any) {
    logger.error({ error: error.message, orderId }, "[SMM] Erreur checkOrderStatus");
    res.status(502).json({
      success: false,
      message: "Impossible de vérifier le statut de la commande",
      error: error.message,
    });
  }
});

export default router;
