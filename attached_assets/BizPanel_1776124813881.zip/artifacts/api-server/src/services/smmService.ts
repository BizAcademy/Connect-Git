import axios from "axios";
import { logger } from "../lib/logger";

const SMM_API_URL = "https://smmpanel.com/api/v2";
const SMM_API_KEY = process.env.SMM_API_KEY || "";

const smmClient = axios.create({
  baseURL: SMM_API_URL,
  headers: { "Content-Type": "application/json" },
  timeout: 15000,
});

/**
 * Récupère la liste de tous les services disponibles depuis l'API SMM.
 */
export async function getServices(): Promise<any[]> {
  logger.info("[SMM] getServices() appelé");

  const response = await smmClient.post("", {
    key: SMM_API_KEY,
    action: "services",
  });

  logger.info({ count: response.data?.length }, "[SMM] services récupérés");
  return response.data;
}

/**
 * Crée une commande SMM.
 * @param serviceId  - ID du service SMM
 * @param link       - Lien cible (profil, post...)
 * @param quantity   - Nombre d'unités à commander
 */
export async function createOrder(
  serviceId: number,
  link: string,
  quantity: number,
): Promise<{ order: number }> {
  logger.info({ serviceId, link, quantity }, "[SMM] createOrder() appelé");

  const response = await smmClient.post("", {
    key: SMM_API_KEY,
    action: "add",
    service: serviceId,
    link,
    quantity,
  });

  logger.info({ orderId: response.data?.order }, "[SMM] commande créée");
  return response.data;
}

/**
 * Vérifie le statut d'une commande SMM.
 * @param orderId - ID de la commande retourné lors de la création
 */
export async function checkOrderStatus(orderId: number): Promise<{
  charge: string;
  start_count: string;
  status: string;
  remains: string;
  currency: string;
}> {
  logger.info({ orderId }, "[SMM] checkOrderStatus() appelé");

  const response = await smmClient.post("", {
    key: SMM_API_KEY,
    action: "status",
    order: orderId,
  });

  logger.info({ orderId, status: response.data?.status }, "[SMM] statut récupéré");
  return response.data;
}
