import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Check } from "lucide-react";

const plans = [
  {
    name: "Starter",
    price: "5 000",
    currency: "FCFA",
    description: "Idéal pour débuter",
    features: [
      "Accès à tous les services",
      "Support par email",
      "Tableau de bord basique",
      "Livraison standard",
    ],
    popular: false,
  },
  {
    name: "Pro",
    price: "20 000",
    currency: "FCFA",
    description: "Le plus populaire",
    features: [
      "Tout dans Starter",
      "Support prioritaire WhatsApp",
      "Livraison express",
      "Bonus de 10% sur recharges",
      "Programme d'affiliation",
    ],
    popular: true,
  },
  {
    name: "Business",
    price: "50 000",
    currency: "FCFA",
    description: "Pour les professionnels",
    features: [
      "Tout dans Pro",
      "Gestionnaire dédié",
      "API personnalisée",
      "Bonus de 20% sur recharges",
      "Tarifs grossiste",
    ],
    popular: false,
  },
];

const PricingSection = () => {
  return (
    <section id="pricing" className="py-24 bg-background">
      <div className="container px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="font-heading text-3xl md:text-4xl font-bold mb-4 text-foreground">
            Rechargez votre compte
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Choisissez le montant qui vous convient et commencez à booster vos réseaux.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {plans.map((plan, i) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
            >
              <Card
                className={`h-full relative ${
                  plan.popular
                    ? "border-primary shadow-lg scale-105"
                    : "border-border"
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full text-xs font-semibold bg-primary text-primary-foreground">
                    Populaire
                  </div>
                )}
                <CardHeader className="text-center pb-2">
                  <CardTitle className="font-heading text-xl text-card-foreground">
                    {plan.name}
                  </CardTitle>
                  <p className="text-muted-foreground text-sm">{plan.description}</p>
                  <div className="mt-4">
                    <span className="font-heading text-4xl font-bold text-card-foreground">
                      {plan.price}
                    </span>
                    <span className="text-muted-foreground ml-1">{plan.currency}</span>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3 mb-6">
                    {plan.features.map((feature) => (
                      <li key={feature} className="flex items-center gap-2 text-sm text-card-foreground">
                        <Check className="text-secondary shrink-0" size={16} />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <Button
                    className="w-full"
                    variant={plan.popular ? "default" : "outline"}
                  >
                    Recharger
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PricingSection;
