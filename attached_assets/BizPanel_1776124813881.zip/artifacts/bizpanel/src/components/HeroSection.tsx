import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ArrowRight, Zap, TrendingUp, Users } from "lucide-react";
import { useSiteContent } from "@/hooks/useSiteContent";
import heroBg from "@/assets/hero-bg.jpg";

const HeroSection = () => {
  const { get } = useSiteContent();

  const bgImage = get("hero_bg") || heroBg;
  const title = get("hero_title", "Boostez votre présence sur les réseaux sociaux");
  const subtitle = get("hero_subtitle", "Abonnés, likes, commentaires et partages pour Instagram, TikTok, Facebook et YouTube. Livraison rapide, prix compétitifs.");
  const ctaText = get("hero_cta", "Commencer maintenant");

  return (
    <section
      id="hero"
      className="relative min-h-screen flex items-center justify-center overflow-hidden pt-16"
    >
      <div className="absolute inset-0">
        <img src={bgImage} alt="" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-foreground/70" />
      </div>

      <div className="container relative z-10 px-4 py-20">
        <div className="max-w-3xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <span className="inline-block px-4 py-1.5 mb-6 rounded-full text-sm font-medium bg-primary/20 text-primary-foreground border border-primary/30">
              🚀 La plateforme #1 de croissance sociale
            </span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="font-heading text-4xl md:text-6xl font-bold tracking-tight mb-6"
            style={{ color: "hsl(0, 0%, 100%)" }}
          >
            {title.includes("réseaux") ? (
              <>
                {title.split("réseaux")[0]}
                <span
                  className="bg-clip-text text-transparent"
                  style={{ backgroundImage: "var(--gradient-hero)" }}
                >
                  réseaux{title.split("réseaux")[1]}
                </span>
              </>
            ) : (
              <span className="bg-clip-text text-transparent" style={{ backgroundImage: "var(--gradient-hero)" }}>
                {title}
              </span>
            )}
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-lg md:text-xl mb-8 max-w-2xl mx-auto"
            style={{ color: "hsl(220, 15%, 75%)" }}
          >
            {subtitle}
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="flex flex-col sm:flex-row gap-4 justify-center"
          >
            <Button size="lg" className="text-base gap-2">
              {ctaText}
              <ArrowRight size={18} />
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="text-base"
              style={{ color: "hsl(0, 0%, 100%)", borderColor: "hsl(25, 95%, 53%, 0.4)" }}
            >
              Voir les services
            </Button>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.5 }}
            className="mt-16 grid grid-cols-3 gap-6 max-w-lg mx-auto"
          >
            {[
              { icon: Users, value: "50K+", label: "Clients" },
              { icon: TrendingUp, value: "10M+", label: "Commandes" },
              { icon: Zap, value: "99.9%", label: "Uptime" },
            ].map((stat) => (
              <div key={stat.label} className="text-center">
                <stat.icon className="mx-auto mb-2 text-primary" size={24} />
                <div className="font-heading text-2xl font-bold" style={{ color: "hsl(0, 0%, 100%)" }}>
                  {stat.value}
                </div>
                <div className="text-sm" style={{ color: "hsl(220, 15%, 65%)" }}>
                  {stat.label}
                </div>
              </div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
