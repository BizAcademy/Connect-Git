import { Instagram, Youtube, Facebook, MessageCircle } from "lucide-react";
import { useSiteContent } from "@/hooks/useSiteContent";

const FooterSection = () => {
  const { get } = useSiteContent();

  const whatsapp = get("footer_whatsapp", "+XXX XXX XXX");
  const email = get("footer_email", "support@bizpanel.com");
  const tagline = get("footer_tagline", "La plateforme leader de croissance sur les réseaux sociaux.");
  const logoImage = get("footer_logo_image");

  const waLink = whatsapp.replace(/\s+/g, "").replace("+", "");

  return (
    <footer id="contact" className="bg-foreground py-16">
      <div className="container px-4">
        <div className="grid md:grid-cols-4 gap-8">
          <div className="md:col-span-2">
            <div className="mb-3">
              {logoImage ? (
                <img src={logoImage} alt="BIZ PANEL" className="h-10 object-contain" />
              ) : (
                <h3 className="font-heading text-2xl font-bold" style={{ color: "hsl(0, 0%, 100%)" }}>
                  <span style={{ color: "hsl(25, 95%, 53%)" }}>BIZ</span>{" "}
                  <span style={{ color: "hsl(215, 85%, 55%)" }}>PANEL</span>
                </h3>
              )}
            </div>
            <p className="text-sm mb-4" style={{ color: "hsl(220, 15%, 65%)" }}>
              {tagline}
            </p>
            <div className="flex gap-3">
              {[Instagram, Facebook, Youtube].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="w-10 h-10 rounded-lg flex items-center justify-center transition-colors hover:opacity-80"
                  style={{ backgroundColor: "hsl(220, 20%, 20%)", color: "hsl(220, 15%, 65%)" }}
                >
                  <Icon size={18} />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-heading font-semibold mb-4" style={{ color: "hsl(0, 0%, 100%)" }}>
              Liens rapides
            </h4>
            <ul className="space-y-2 text-sm" style={{ color: "hsl(220, 15%, 65%)" }}>
              {["Accueil", "Services", "Tarifs", "FAQ", "Contact"].map((link) => (
                <li key={link}>
                  <a href="#" className="hover:text-primary transition-colors">{link}</a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-heading font-semibold mb-4" style={{ color: "hsl(0, 0%, 100%)" }}>
              Support
            </h4>
            <ul className="space-y-2 text-sm" style={{ color: "hsl(220, 15%, 65%)" }}>
              <li className="flex items-center gap-2">
                <MessageCircle size={16} className="text-secondary" />
                WhatsApp : {whatsapp}
              </li>
              <li>Email : {email}</li>
            </ul>
          </div>
        </div>

        <div
          className="mt-12 pt-8 text-center text-sm"
          style={{ borderTop: "1px solid hsl(220, 20%, 20%)", color: "hsl(220, 15%, 50%)" }}
        >
          © {new Date().getFullYear()} BIZ PANEL. Tous droits réservés.
        </div>
      </div>

      <a
        href={`https://wa.me/${waLink}`}
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full bg-secondary flex items-center justify-center shadow-lg hover:scale-110 transition-transform"
        title={`WhatsApp : ${whatsapp}`}
      >
        <MessageCircle className="text-secondary-foreground" size={26} />
      </a>
    </footer>
  );
};

export default FooterSection;
