import { motion } from "framer-motion";
import { Shield, Zap, Clock, Headphones, CreditCard, RefreshCw } from "lucide-react";

const features = [
  {
    icon: Zap,
    title: "Livraison rapide",
    description: "Vos commandes sont traitées et livrées en quelques minutes.",
  },
  {
    icon: Shield,
    title: "100% sécurisé",
    description: "Vos données sont protégées avec un chiffrement de pointe.",
  },
  {
    icon: Clock,
    title: "Disponible 24/7",
    description: "Notre plateforme fonctionne en continu, jour et nuit.",
  },
  {
    icon: CreditCard,
    title: "Paiement facile",
    description: "Plusieurs méthodes de paiement acceptées pour votre confort.",
  },
  {
    icon: RefreshCw,
    title: "Recharge automatique",
    description: "Système de recharge garantie si les chiffres baissent.",
  },
  {
    icon: Headphones,
    title: "Support réactif",
    description: "Notre équipe vous accompagne via WhatsApp et email.",
  },
];

const FeaturesSection = () => {
  return (
    <section id="features" className="py-24 bg-muted/50">
      <div className="container px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="font-heading text-3xl md:text-4xl font-bold mb-4 text-foreground">
            Pourquoi choisir BIZ PANEL ?
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Une plateforme conçue pour vous offrir les meilleurs résultats.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, i) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
              className="flex gap-4 p-6 rounded-xl bg-card border border-border hover:shadow-md transition-shadow"
            >
              <div className="shrink-0 w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                <feature.icon className="text-primary" size={22} />
              </div>
              <div>
                <h3 className="font-heading font-semibold text-lg mb-1 text-card-foreground">
                  {feature.title}
                </h3>
                <p className="text-muted-foreground text-sm">
                  {feature.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;
