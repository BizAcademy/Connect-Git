import { motion } from "framer-motion";
import { Instagram, Youtube, Facebook } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useSiteContent } from "@/hooks/useSiteContent";

const TikTokIcon = () => (
  <svg viewBox="0 0 24 24" fill="currentColor" className="w-8 h-8">
    <path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-2.88 2.5 2.89 2.89 0 01-2.89-2.89 2.89 2.89 0 012.89-2.89c.28 0 .54.04.79.1V9.01a6.27 6.27 0 00-.79-.05 6.34 6.34 0 00-6.34 6.34 6.34 6.34 0 006.34 6.34 6.34 6.34 0 006.34-6.34V8.75a8.18 8.18 0 004.76 1.52V6.84a4.84 4.84 0 01-1-.15z" />
  </svg>
);

const platforms = [
  {
    name: "Instagram",
    icon: Instagram,
    iconKey: "services_icon_instagram",
    color: "hsl(25, 95%, 53%)",
    services: ["Abonnés", "Likes", "Commentaires", "Vues Reels"],
    description: "Augmentez votre visibilité sur Instagram avec nos services premium.",
  },
  {
    name: "TikTok",
    icon: TikTokIcon,
    iconKey: "services_icon_tiktok",
    color: "hsl(152, 60%, 45%)",
    services: ["Abonnés", "Likes", "Vues", "Partages"],
    description: "Devenez viral sur TikTok grâce à notre boost de croissance.",
  },
  {
    name: "Facebook",
    icon: Facebook,
    iconKey: "services_icon_facebook",
    color: "hsl(215, 85%, 55%)",
    services: ["J'aime Page", "Likes Posts", "Commentaires", "Partages"],
    description: "Développez votre communauté Facebook rapidement.",
  },
  {
    name: "YouTube",
    icon: Youtube,
    iconKey: "services_icon_youtube",
    color: "hsl(0, 72%, 51%)",
    services: ["Abonnés", "Vues", "Likes", "Commentaires"],
    description: "Boostez votre chaîne YouTube avec des résultats réels.",
  },
];

const ServicesSection = () => {
  const { get } = useSiteContent();
  const sectionTitle = get("services_title", "Nos services par plateforme");

  return (
    <section id="services" className="py-24 bg-background">
      <div className="container px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="font-heading text-3xl md:text-4xl font-bold mb-4 text-foreground">
            {sectionTitle}
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Des solutions de croissance pour toutes les grandes plateformes sociales.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {platforms.map((platform, i) => {
            const customIcon = get(platform.iconKey);
            return (
              <motion.div
                key={platform.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <Card className="h-full hover:shadow-lg transition-shadow border-border bg-card group">
                  <CardHeader className="text-center pb-2">
                    <div
                      className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-3 transition-transform group-hover:scale-110 overflow-hidden"
                      style={{ backgroundColor: platform.color, color: "white" }}
                    >
                      {customIcon ? (
                        <img src={customIcon} alt={platform.name} className="w-full h-full object-cover" />
                      ) : (
                        <platform.icon />
                      )}
                    </div>
                    <CardTitle className="font-heading text-xl text-card-foreground">
                      {platform.name}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="text-center">
                    <p className="text-muted-foreground text-sm mb-4">{platform.description}</p>
                    <div className="flex flex-wrap gap-2 justify-center">
                      {platform.services.map((service) => (
                        <span key={service} className="px-3 py-1 rounded-full text-xs font-medium bg-muted text-muted-foreground">
                          {service}
                        </span>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
