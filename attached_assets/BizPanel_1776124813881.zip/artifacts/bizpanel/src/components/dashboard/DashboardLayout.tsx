import { useState } from "react";
import { useNavigate, useLocation, Outlet } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import {
  LayoutDashboard, ShoppingCart, Clock, Wallet, CreditCard,
  LogOut, Menu, X, ChevronRight
} from "lucide-react";

const menuItems = [
  { label: "Tableau de bord", href: "/dashboard", icon: LayoutDashboard },
  { label: "Nouvelle commande", href: "/dashboard/order", icon: ShoppingCart },
  { label: "Mes commandes", href: "/dashboard/orders", icon: Clock },
  { label: "Recharger", href: "/dashboard/deposit", icon: Wallet },
  { label: "Historique paiements", href: "/dashboard/payments", icon: CreditCard },
];

export const DashboardLayout = () => {
  const { user, profile, loading, signOut } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!user) {
    navigate("/auth");
    return null;
  }

  const isActive = (href: string) =>
    href === "/dashboard"
      ? location.pathname === "/dashboard"
      : location.pathname.startsWith(href);

  return (
    <div className="min-h-screen bg-background flex">
      {/* Overlay mobile */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed inset-y-0 left-0 z-50 w-64 bg-card border-r border-border flex flex-col transform transition-transform duration-200 ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        } lg:translate-x-0 lg:static lg:z-auto`}
      >
        <div className="p-4 border-b border-border flex items-center justify-between">
          <button onClick={() => navigate("/")} className="font-heading text-xl font-bold">
            <span className="text-primary">BIZ</span> <span className="text-accent">PANEL</span>
          </button>
          <button className="lg:hidden" onClick={() => setSidebarOpen(false)}>
            <X size={20} />
          </button>
        </div>

        {/* User info */}
        <div className="p-4 border-b border-border">
          <p className="font-medium text-sm">{profile?.username || user.email}</p>
          <p className="text-xs text-muted-foreground">{user.email}</p>
          <div className="mt-2 bg-primary/10 rounded-md px-3 py-1.5">
            <span className="text-xs text-muted-foreground">Solde</span>
            <p className="font-bold text-primary text-sm">
              {Number(profile?.balance || 0).toLocaleString()} FCFA
            </p>
          </div>
        </div>

        {/* Navigation */}
        <nav className="p-3 space-y-1 flex-1">
          {menuItems.map((item) => (
            <button
              key={item.href}
              onClick={() => { navigate(item.href); setSidebarOpen(false); }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-md text-sm transition-colors ${
                isActive(item.href)
                  ? "bg-primary/10 text-primary font-medium"
                  : "text-muted-foreground hover:bg-muted hover:text-foreground"
              }`}
            >
              <item.icon size={16} />
              {item.label}
              {isActive(item.href) && <ChevronRight size={14} className="ml-auto" />}
            </button>
          ))}
        </nav>

        <div className="p-3 border-t border-border">
          <Button
            variant="ghost"
            size="sm"
            className="w-full justify-start gap-2 text-muted-foreground"
            onClick={signOut}
          >
            <LogOut size={16} /> Déconnexion
          </Button>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 min-h-screen flex flex-col overflow-hidden">
        <header className="bg-card border-b border-border p-4 flex items-center gap-3 sticky top-0 z-30">
          <button className="lg:hidden" onClick={() => setSidebarOpen(true)}>
            <Menu size={24} />
          </button>
          <div>
            <h1 className="font-heading text-base font-semibold">
              Bonjour, {profile?.username} 👋
            </h1>
            <p className="text-xs text-muted-foreground">Bienvenue sur BizPanel</p>
          </div>
          <Button size="sm" className="ml-auto" onClick={() => navigate("/dashboard/deposit")}>
            <Wallet size={14} className="mr-1" /> Recharger
          </Button>
        </header>

        <div className="flex-1 p-4 md:p-6 overflow-auto">
          <Outlet />
        </div>
      </main>
    </div>
  );
};
