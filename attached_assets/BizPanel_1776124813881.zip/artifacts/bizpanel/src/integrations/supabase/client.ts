import { createClient } from '@supabase/supabase-js';
import type { Database } from './types';

const SUPABASE_URL = "https://yqahqnxjflthazphhpqx.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InlxYWhxbnhqZmx0aGF6cGhocHF4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzYwMTEzNTYsImV4cCI6MjA5MTU4NzM1Nn0.f56ogQYWBK8cqzyp-P6--K3n3y0JVZGkw6VtSF462jI";

export const supabase = createClient<Database>(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    storage: localStorage,
    persistSession: true,
    autoRefreshToken: true,
  }
});
