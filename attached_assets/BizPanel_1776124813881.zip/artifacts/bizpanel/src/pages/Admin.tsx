import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { invalidateSiteContentCache } from "@/hooks/useSiteContent";
import { toast } from "sonner";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Users, ShoppingCart, CreditCard, Settings, Layers,
  FileText, LogOut, Shield, Edit2, Save, X, ToggleLeft, ToggleRight,
  Plus, Trash2, RefreshCw, Image, Type, Link, CheckCircle2
} from "lucide-react";

const AdminUsers = () => {
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<string | null>(null);
  const [editData, setEditData] = useState<any>({});

  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from("profiles").select("*").order("created_at", { ascending: false });
    setUsers(data || []);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const save = async (userId: string) => {
    const { error } = await supabase.from("profiles").update({
      username: editData.username,
      balance: Number(editData.balance),
      is_active: editData.is_active,
    }).eq("user_id", userId);
    if (error) { toast.error(error.message); return; }
    toast.success("Utilisateur mis à jour");
    setEditing(null);
    load();
  };

  const toggleActive = async (user: any) => {
    await supabase.from("profiles").update({ is_active: !user.is_active }).eq("user_id", user.user_id);
    load();
    toast.success(user.is_active ? "Compte désactivé" : "Compte activé");
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">{users.length} utilisateur(s)</p>
        <Button variant="outline" size="sm" onClick={load}><RefreshCw size={14} className="mr-1" />Actualiser</Button>
      </div>
      {loading ? <div className="flex justify-center py-8"><div className="animate-spin h-7 w-7 border-4 border-primary border-t-transparent rounded-full" /></div> : (
        <div className="space-y-3">
          {users.map(u => (
            <Card key={u.user_id}>
              <CardContent className="p-4">
                {editing === u.user_id ? (
                  <div className="space-y-3">
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <Label className="text-xs">Username</Label>
                        <Input value={editData.username} onChange={e => setEditData({ ...editData, username: e.target.value })} className="h-8 mt-1" />
                      </div>
                      <div>
                        <Label className="text-xs">Solde (FCFA)</Label>
                        <Input type="number" value={editData.balance} onChange={e => setEditData({ ...editData, balance: e.target.value })} className="h-8 mt-1" />
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" onClick={() => save(u.user_id)}><Save size={13} className="mr-1" />Enregistrer</Button>
                      <Button size="sm" variant="ghost" onClick={() => setEditing(null)}><X size={13} /></Button>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center gap-3 flex-wrap">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="font-medium text-sm">{u.username}</p>
                        <span className={`text-xs px-1.5 py-0.5 rounded-full ${u.is_active ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`}>
                          {u.is_active ? "Actif" : "Inactif"}
                        </span>
                      </div>
                      <p className="text-xs text-muted-foreground">{u.email}</p>
                    </div>
                    <p className="text-sm font-bold text-primary">{Number(u.balance).toLocaleString()} FCFA</p>
                    <div className="flex gap-1">
                      <Button size="sm" variant="outline" className="h-7 px-2" onClick={() => { setEditing(u.user_id); setEditData({ username: u.username, balance: u.balance, is_active: u.is_active }); }}>
                        <Edit2 size={13} />
                      </Button>
                      <Button size="sm" variant="outline" className="h-7 px-2" onClick={() => toggleActive(u)}>
                        {u.is_active ? <ToggleRight size={13} className="text-green-600" /> : <ToggleLeft size={13} className="text-red-500" />}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

const STATUSES = ["pending", "processing", "completed", "cancelled"];
const STATUS_LABELS: Record<string, string> = { pending: "En attente", processing: "En cours", completed: "Terminé", cancelled: "Annulé" };

const AdminOrders = () => {
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from("orders").select("*").order("created_at", { ascending: false }).limit(100);
    setOrders(data || []);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const updateStatus = async (id: string, status: string) => {
    await supabase.from("orders").update({ status }).eq("id", id);
    setOrders(orders.map(o => o.id === id ? { ...o, status } : o));
    toast.success("Statut mis à jour");
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">{orders.length} commande(s)</p>
        <Button variant="outline" size="sm" onClick={load}><RefreshCw size={14} className="mr-1" />Actualiser</Button>
      </div>
      {loading ? <div className="flex justify-center py-8"><div className="animate-spin h-7 w-7 border-4 border-primary border-t-transparent rounded-full" /></div> : (
        <div className="space-y-3">
          {orders.map(o => (
            <Card key={o.id}>
              <CardContent className="p-4">
                <div className="flex items-start gap-3 flex-wrap">
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm">{o.service_name}</p>
                    <p className="text-xs text-muted-foreground">{o.service_category} · {Number(o.quantity).toLocaleString()} unités · {Number(o.price).toLocaleString()} FCFA</p>
                    <p className="text-xs text-muted-foreground truncate">🔗 {o.link}</p>
                    <p className="text-xs text-muted-foreground">{new Date(o.created_at).toLocaleDateString("fr-FR")}</p>
                  </div>
                  <select
                    value={o.status}
                    onChange={e => updateStatus(o.id, e.target.value)}
                    className="text-xs border rounded px-2 py-1 bg-background"
                  >
                    {STATUSES.map(s => <option key={s} value={s}>{STATUS_LABELS[s]}</option>)}
                  </select>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

const AdminPayments = () => {
  const [payments, setPayments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from("payments").select("*, profiles(username, email)").order("created_at", { ascending: false }).limit(100);
    setPayments(data || []);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const validate = async (payment: any) => {
    if (payment.status === "completed") { toast.error("Déjà validé"); return; }
    const { data: prof } = await supabase.from("profiles").select("balance").eq("user_id", payment.user_id).single();
    if (prof) {
      await supabase.from("profiles").update({ balance: Number(prof.balance) + Number(payment.amount) }).eq("user_id", payment.user_id);
    }
    await supabase.from("payments").update({ status: "completed" }).eq("id", payment.id);
    toast.success(`${Number(payment.amount).toLocaleString()} FCFA crédités`);
    load();
  };

  const reject = async (id: string) => {
    await supabase.from("payments").update({ status: "rejected" }).eq("id", id);
    toast.success("Paiement rejeté");
    load();
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">{payments.length} paiement(s)</p>
        <Button variant="outline" size="sm" onClick={load}><RefreshCw size={14} className="mr-1" />Actualiser</Button>
      </div>
      {loading ? <div className="flex justify-center py-8"><div className="animate-spin h-7 w-7 border-4 border-primary border-t-transparent rounded-full" /></div> : (
        <div className="space-y-3">
          {payments.map(p => (
            <Card key={p.id}>
              <CardContent className="p-4 flex items-center gap-3 flex-wrap">
                <div className="flex-1 min-w-0">
                  <p className="font-bold text-sm">{Number(p.amount).toLocaleString()} FCFA</p>
                  <p className="text-xs text-muted-foreground">{(p.profiles as any)?.username} · {p.method?.toUpperCase()}</p>
                  <p className="text-xs text-muted-foreground">{new Date(p.created_at).toLocaleDateString("fr-FR")}</p>
                  {p.reference && <p className="text-xs text-muted-foreground">Réf: {p.reference}</p>}
                </div>
                <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${p.status === "completed" ? "bg-green-100 text-green-700" : p.status === "rejected" ? "bg-red-100 text-red-700" : "bg-yellow-100 text-yellow-700"}`}>
                  {p.status === "completed" ? "Validé" : p.status === "rejected" ? "Rejeté" : "En attente"}
                </span>
                {p.status === "pending" && (
                  <div className="flex gap-1">
                    <Button size="sm" className="h-7 px-2 text-xs" onClick={() => validate(p)}>Valider</Button>
                    <Button size="sm" variant="destructive" className="h-7 px-2 text-xs" onClick={() => reject(p.id)}>Rejeter</Button>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

const CATEGORIES = ["Instagram", "TikTok", "Facebook", "YouTube", "Telegram"];

const AdminServices = () => {
  const [services, setServices] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<string | null>(null);
  const [editData, setEditData] = useState<any>({});
  const [showAdd, setShowAdd] = useState(false);
  const [newService, setNewService] = useState({ category: "Instagram", name: "", description: "", price_per_1000: 0, min_quantity: 100, max_quantity: 10000, delivery_time: "0-24h" });

  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from("services").select("*").order("sort_order");
    setServices(data || []);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const save = async (id: string) => {
    const { error } = await supabase.from("services").update(editData).eq("id", id);
    if (error) { toast.error(error.message); return; }
    toast.success("Service mis à jour");
    setEditing(null);
    load();
  };

  const addService = async () => {
    if (!newService.name) { toast.error("Nom requis"); return; }
    const { error } = await supabase.from("services").insert(newService);
    if (error) { toast.error(error.message); return; }
    toast.success("Service ajouté");
    setShowAdd(false);
    setNewService({ category: "Instagram", name: "", description: "", price_per_1000: 0, min_quantity: 100, max_quantity: 10000, delivery_time: "0-24h" });
    load();
  };

  const deleteService = async (id: string) => {
    if (!confirm("Supprimer ce service ?")) return;
    await supabase.from("services").delete().eq("id", id);
    load();
    toast.success("Service supprimé");
  };

  const toggleActive = async (s: any) => {
    await supabase.from("services").update({ is_active: !s.is_active }).eq("id", s.id);
    load();
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">{services.length} service(s)</p>
        <Button size="sm" onClick={() => setShowAdd(!showAdd)}><Plus size={14} className="mr-1" />Ajouter</Button>
      </div>

      {showAdd && (
        <Card className="border-primary/30">
          <CardHeader><CardTitle className="text-sm">Nouveau service</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs">Catégorie</Label>
                <select value={newService.category} onChange={e => setNewService({ ...newService, category: e.target.value })} className="w-full border rounded px-2 py-1.5 text-sm mt-1 bg-background">
                  {CATEGORIES.map(c => <option key={c}>{c}</option>)}
                </select>
              </div>
              <div>
                <Label className="text-xs">Nom</Label>
                <Input value={newService.name} onChange={e => setNewService({ ...newService, name: e.target.value })} className="h-8 mt-1" />
              </div>
              <div>
                <Label className="text-xs">Prix/1000 (FCFA)</Label>
                <Input type="number" value={newService.price_per_1000} onChange={e => setNewService({ ...newService, price_per_1000: Number(e.target.value) })} className="h-8 mt-1" />
              </div>
              <div>
                <Label className="text-xs">Livraison</Label>
                <Input value={newService.delivery_time} onChange={e => setNewService({ ...newService, delivery_time: e.target.value })} className="h-8 mt-1" />
              </div>
              <div>
                <Label className="text-xs">Qté min</Label>
                <Input type="number" value={newService.min_quantity} onChange={e => setNewService({ ...newService, min_quantity: Number(e.target.value) })} className="h-8 mt-1" />
              </div>
              <div>
                <Label className="text-xs">Qté max</Label>
                <Input type="number" value={newService.max_quantity} onChange={e => setNewService({ ...newService, max_quantity: Number(e.target.value) })} className="h-8 mt-1" />
              </div>
            </div>
            <div>
              <Label className="text-xs">Description</Label>
              <textarea value={newService.description} onChange={e => setNewService({ ...newService, description: e.target.value })} rows={2} className="w-full border rounded px-2 py-1.5 text-sm mt-1 bg-background resize-none" />
            </div>
            <div className="flex gap-2">
              <Button size="sm" onClick={addService}>Ajouter</Button>
              <Button size="sm" variant="ghost" onClick={() => setShowAdd(false)}>Annuler</Button>
            </div>
          </CardContent>
        </Card>
      )}

      {loading ? <div className="flex justify-center py-8"><div className="animate-spin h-7 w-7 border-4 border-primary border-t-transparent rounded-full" /></div> : (
        <div className="space-y-3">
          {services.map(s => (
            <Card key={s.id} className={!s.is_active ? "opacity-60" : ""}>
              <CardContent className="p-4">
                {editing === s.id ? (
                  <div className="space-y-3">
                    <div className="grid grid-cols-2 gap-3">
                      <div><Label className="text-xs">Nom</Label><Input value={editData.name} onChange={e => setEditData({ ...editData, name: e.target.value })} className="h-8 mt-1" /></div>
                      <div><Label className="text-xs">Prix/1000</Label><Input type="number" value={editData.price_per_1000} onChange={e => setEditData({ ...editData, price_per_1000: e.target.value })} className="h-8 mt-1" /></div>
                      <div><Label className="text-xs">Qté min</Label><Input type="number" value={editData.min_quantity} onChange={e => setEditData({ ...editData, min_quantity: e.target.value })} className="h-8 mt-1" /></div>
                      <div><Label className="text-xs">Qté max</Label><Input type="number" value={editData.max_quantity} onChange={e => setEditData({ ...editData, max_quantity: e.target.value })} className="h-8 mt-1" /></div>
                      <div><Label className="text-xs">Livraison</Label><Input value={editData.delivery_time} onChange={e => setEditData({ ...editData, delivery_time: e.target.value })} className="h-8 mt-1" /></div>
                    </div>
                    <div><Label className="text-xs">Description</Label><textarea value={editData.description} onChange={e => setEditData({ ...editData, description: e.target.value })} rows={2} className="w-full border rounded px-2 py-1.5 text-sm mt-1 bg-background resize-none" /></div>
                    <div className="flex gap-2">
                      <Button size="sm" onClick={() => save(s.id)}><Save size={12} className="mr-1" />Enregistrer</Button>
                      <Button size="sm" variant="ghost" onClick={() => setEditing(null)}>Annuler</Button>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center gap-3 flex-wrap">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-xs bg-muted px-2 py-0.5 rounded-full">{s.category}</span>
                        <p className="font-medium text-sm">{s.name}</p>
                      </div>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {Number(s.price_per_1000).toLocaleString()} FCFA/1000 · {s.min_quantity}–{s.max_quantity} · {s.delivery_time}
                      </p>
                    </div>
                    <div className="flex gap-1">
                      <Button size="sm" variant="outline" className="h-7 px-2" onClick={() => { setEditing(s.id); setEditData({ ...s }); }}><Edit2 size={12} /></Button>
                      <Button size="sm" variant="outline" className="h-7 px-2" onClick={() => toggleActive(s)}>
                        {s.is_active ? <ToggleRight size={13} className="text-green-600" /> : <ToggleLeft size={13} className="text-red-500" />}
                      </Button>
                      <Button size="sm" variant="outline" className="h-7 px-2 text-red-500" onClick={() => deleteService(s.id)}><Trash2 size={12} /></Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

const SECTION_LABELS: Record<string, string> = {
  hero: "🖼️ Section Hero",
  services: "📱 Section Services",
  "fonctionnalités": "⚡ Fonctionnalités",
  tarifs: "💰 Tarifs",
  footer: "🦶 Pied de page",
  navigation: "🧭 Navigation",
};

const AdminContent = () => {
  const [content, setContent] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState<string | null>(null);
  const [saved, setSaved] = useState<string | null>(null);
  const [urlErrors, setUrlErrors] = useState<Record<string, boolean>>({});

  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from("site_content").select("*").order("section");
    setContent(data || []);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const update = (id: string, value: string) => {
    setContent(content.map(c => c.id === id ? { ...c, value } : c));
    setUrlErrors(prev => ({ ...prev, [id]: false }));
  };

  const save = async (item: any) => {
    setSaving(item.id);
    const { error } = await supabase.from("site_content").update({ value: item.value }).eq("id", item.id);
    setSaving(null);
    if (error) { toast.error(error.message); return; }
    invalidateSiteContentCache();
    setSaved(item.id);
    setTimeout(() => setSaved(null), 2000);
    toast.success(`✅ "${item.label}" mis à jour`);
  };

  const grouped = content.reduce((acc: any, c) => {
    if (!acc[c.section]) acc[c.section] = [];
    acc[c.section].push(c);
    return acc;
  }, {});

  const imageCount = content.filter(c => c.type === "image").length;
  const textCount = content.filter(c => c.type === "text").length;

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4 flex-wrap">
        <div className="flex items-center gap-2 text-sm text-muted-foreground bg-muted px-3 py-1.5 rounded-full">
          <Image size={14} /> {imageCount} image(s)
        </div>
        <div className="flex items-center gap-2 text-sm text-muted-foreground bg-muted px-3 py-1.5 rounded-full">
          <Type size={14} /> {textCount} texte(s)
        </div>
        <p className="text-xs text-muted-foreground">Collez une URL d'image pour remplacer les visuels du site.</p>
      </div>

      {loading ? (
        <div className="flex justify-center py-8"><div className="animate-spin h-7 w-7 border-4 border-primary border-t-transparent rounded-full" /></div>
      ) : (
        Object.entries(grouped).map(([section, items]: [string, any]) => (
          <Card key={section}>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-semibold">
                {SECTION_LABELS[section] || section}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-5">
              {items.map((item: any) => (
                <div key={item.id} className="space-y-2">
                  <div className="flex items-center gap-2">
                    {item.type === "image"
                      ? <Image size={13} className="text-accent" />
                      : <Type size={13} className="text-muted-foreground" />
                    }
                    <Label className="text-xs font-medium">{item.label}</Label>
                    <span className={`text-xs px-1.5 py-0.5 rounded-full ${item.type === "image" ? "bg-accent/10 text-accent" : "bg-muted text-muted-foreground"}`}>
                      {item.type === "image" ? "Image" : "Texte"}
                    </span>
                  </div>

                  {item.type === "image" && (
                    <div className="flex gap-3 items-start">
                      <div className="shrink-0 w-24 h-16 rounded-lg border border-border bg-muted overflow-hidden flex items-center justify-center">
                        {item.value && !urlErrors[item.id] ? (
                          <img
                            src={item.value}
                            alt={item.label}
                            className="w-full h-full object-cover"
                            onError={() => setUrlErrors(prev => ({ ...prev, [item.id]: true }))}
                          />
                        ) : (
                          <div className="text-center text-muted-foreground">
                            <Image size={20} className="mx-auto mb-1 opacity-40" />
                            <p className="text-xs opacity-60">{urlErrors[item.id] ? "URL invalide" : "Aucune image"}</p>
                          </div>
                        )}
                      </div>
                      <div className="flex-1 space-y-1.5">
                        <div className="flex items-center gap-1 text-xs text-muted-foreground mb-1">
                          <Link size={11} /> URL de l'image
                        </div>
                        <div className="flex gap-2">
                          <Input
                            value={item.value}
                            onChange={e => update(item.id, e.target.value)}
                            placeholder="https://exemple.com/image.jpg"
                            className={`h-9 text-sm ${urlErrors[item.id] ? "border-red-400" : ""}`}
                          />
                          <Button
                            size="sm"
                            className="h-9 px-3 shrink-0"
                            onClick={() => save(item)}
                            disabled={saving === item.id}
                          >
                            {saved === item.id
                              ? <CheckCircle2 size={14} className="text-green-300" />
                              : saving === item.id
                              ? <RefreshCw size={13} className="animate-spin" />
                              : <Save size={13} />
                            }
                          </Button>
                        </div>
                      </div>
                    </div>
                  )}

                  {item.type === "text" && (
                    <div className="flex gap-2">
                      <Input
                        value={item.value}
                        onChange={e => update(item.id, e.target.value)}
                        className="flex-1 h-9 text-sm"
                      />
                      <Button
                        size="sm"
                        className="h-9 px-3 shrink-0"
                        onClick={() => save(item)}
                        disabled={saving === item.id}
                      >
                        {saved === item.id
                          ? <CheckCircle2 size={14} className="text-green-300" />
                          : saving === item.id
                          ? <RefreshCw size={13} className="animate-spin" />
                          : <Save size={13} />
                        }
                      </Button>
                    </div>
                  )}
                </div>
              ))}
            </CardContent>
          </Card>
        ))
      )}
    </div>
  );
};

const AdminSettings = () => {
  const [settings, setSettings] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    supabase.from("settings").select("*").then(({ data }) => {
      setSettings(data || []);
      setLoading(false);
    });
  }, []);

  const update = (key: string, value: string) => {
    setSettings(settings.map(s => s.key === key ? { ...s, value } : s));
  };

  const saveAll = async () => {
    setSaving(true);
    for (const s of settings) {
      await supabase.from("settings").update({ value: s.value }).eq("key", s.key);
    }
    setSaving(false);
    toast.success("Paramètres enregistrés");
  };

  const LABELS: Record<string, string> = {
    smm_api_url: "URL API SMM",
    smm_api_key: "Clé API SMM",
    soleaspay_merchant_id: "Merchant ID SoleasPay",
    soleaspay_api_key: "Clé API SoleasPay",
    soleaspay_callback_url: "Callback URL SoleasPay",
  };

  return (
    <div className="space-y-4 max-w-xl">
      {loading ? <div className="flex justify-center py-8"><div className="animate-spin h-7 w-7 border-4 border-primary border-t-transparent rounded-full" /></div> : (
        <>
          <Card>
            <CardHeader><CardTitle className="text-sm">API SMM</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              {settings.filter(s => s.key.startsWith("smm")).map(s => (
                <div key={s.key}>
                  <Label className="text-xs">{LABELS[s.key] || s.key}</Label>
                  <Input value={s.value} onChange={e => update(s.key, e.target.value)} className="mt-1 h-8 text-sm" />
                </div>
              ))}
            </CardContent>
          </Card>
          <Card>
            <CardHeader><CardTitle className="text-sm">SoleasPay</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              {settings.filter(s => s.key.startsWith("soleaspay")).map(s => (
                <div key={s.key}>
                  <Label className="text-xs">{LABELS[s.key] || s.key}</Label>
                  <Input value={s.value} onChange={e => update(s.key, e.target.value)} className="mt-1 h-8 text-sm" type={s.key.includes("key") ? "password" : "text"} />
                </div>
              ))}
            </CardContent>
          </Card>
          <Button onClick={saveAll} disabled={saving} className="w-full">
            {saving ? "Enregistrement..." : "Enregistrer tous les paramètres"}
          </Button>
        </>
      )}
    </div>
  );
};

export default function Admin() {
  const { user, loading, signOut } = useAuth();
  const navigate = useNavigate();
  const [isAdmin, setIsAdmin] = useState(false);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    if (loading) return;
    if (!user) { navigate("/auth"); return; }

    supabase.rpc("has_role", { _user_id: user.id, _role: "admin" }).then(({ data }) => {
      if (!data) { navigate("/dashboard"); toast.error("Accès refusé"); }
      else setIsAdmin(true);
      setChecking(false);
    });
  }, [user, loading]);

  if (loading || checking) {
    return <div className="min-h-screen flex items-center justify-center"><div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full" /></div>;
  }

  if (!isAdmin) return null;

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-card border-b border-border px-6 py-4 flex items-center justify-between sticky top-0 z-30">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
            <Shield size={16} className="text-primary" />
          </div>
          <div>
            <p className="font-heading font-bold text-sm">
              <span className="text-primary">BIZ</span> <span className="text-accent">PANEL</span>
              <span className="ml-2 text-xs bg-primary text-primary-foreground px-1.5 py-0.5 rounded">ADMIN</span>
            </p>
            <p className="text-xs text-muted-foreground">Panneau d'administration</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={() => navigate("/dashboard")}>Tableau de bord</Button>
          <Button variant="ghost" size="sm" onClick={signOut}><LogOut size={14} /></Button>
        </div>
      </header>

      <div className="max-w-5xl mx-auto p-4 md:p-6">
        <Tabs defaultValue="users">
          <TabsList className="grid grid-cols-3 md:grid-cols-6 mb-6 h-auto gap-1">
            <TabsTrigger value="users" className="flex flex-col gap-1 py-2 text-xs"><Users size={15} />Utilisateurs</TabsTrigger>
            <TabsTrigger value="orders" className="flex flex-col gap-1 py-2 text-xs"><ShoppingCart size={15} />Commandes</TabsTrigger>
            <TabsTrigger value="payments" className="flex flex-col gap-1 py-2 text-xs"><CreditCard size={15} />Paiements</TabsTrigger>
            <TabsTrigger value="services" className="flex flex-col gap-1 py-2 text-xs"><Layers size={15} />Services</TabsTrigger>
            <TabsTrigger value="content" className="flex flex-col gap-1 py-2 text-xs"><FileText size={15} />Contenu</TabsTrigger>
            <TabsTrigger value="settings" className="flex flex-col gap-1 py-2 text-xs"><Settings size={15} />Paramètres</TabsTrigger>
          </TabsList>

          <TabsContent value="users"><AdminUsers /></TabsContent>
          <TabsContent value="orders"><AdminOrders /></TabsContent>
          <TabsContent value="payments"><AdminPayments /></TabsContent>
          <TabsContent value="services"><AdminServices /></TabsContent>
          <TabsContent value="content"><AdminContent /></TabsContent>
          <TabsContent value="settings"><AdminSettings /></TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
