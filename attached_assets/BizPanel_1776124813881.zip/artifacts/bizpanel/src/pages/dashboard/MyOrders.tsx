import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { RefreshCw, Search, ShoppingCart } from "lucide-react";
import { useNavigate } from "react-router-dom";

const STATUS = {
  pending: { label: "En attente", className: "bg-yellow-100 text-yellow-800 border-yellow-200" },
  processing: { label: "En cours", className: "bg-blue-100 text-blue-800 border-blue-200" },
  completed: { label: "Terminé", className: "bg-green-100 text-green-800 border-green-200" },
  cancelled: { label: "Annulé", className: "bg-red-100 text-red-800 border-red-200" },
};

interface Order {
  id: string;
  service_name: string;
  service_category: string;
  link: string;
  quantity: number;
  price: number;
  status: string;
  created_at: string;
  external_order_id: string | null;
}

export default function MyOrders() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");

  const load = async () => {
    if (!user) return;
    setLoading(true);
    const { data } = await supabase
      .from("orders").select("*").eq("user_id", user.id)
      .order("created_at", { ascending: false });
    setOrders(data || []);
    setLoading(false);
  };

  useEffect(() => { load(); }, [user]);

  useEffect(() => {
    const id = setInterval(load, 30000);
    return () => clearInterval(id);
  }, [user]);

  const filtered = orders.filter(o => {
    const matchSearch = search === "" || o.service_name.toLowerCase().includes(search.toLowerCase()) || o.link.toLowerCase().includes(search.toLowerCase());
    const matchFilter = filter === "all" || o.status === filter;
    return matchSearch && matchFilter;
  });

  return (
    <div className="space-y-5 max-w-4xl">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold font-heading">Mes commandes</h2>
          <p className="text-sm text-muted-foreground">{orders.length} commande(s) au total</p>
        </div>
        <Button variant="outline" size="sm" onClick={load} disabled={loading}>
          <RefreshCw size={14} className={`mr-1 ${loading ? "animate-spin" : ""}`} />
          Actualiser
        </Button>
      </div>

      <div className="flex flex-wrap gap-2">
        {[["all", "Toutes"], ["pending", "En attente"], ["processing", "En cours"], ["completed", "Terminées"], ["cancelled", "Annulées"]].map(([val, label]) => (
          <button
            key={val}
            onClick={() => setFilter(val)}
            className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-colors ${
              filter === val ? "bg-primary text-primary-foreground border-primary" : "border-border text-muted-foreground hover:border-primary"
            }`}
          >
            {label}
          </button>
        ))}
        <div className="relative ml-auto">
          <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input placeholder="Rechercher..." value={search} onChange={e => setSearch(e.target.value)} className="pl-8 h-8 text-xs w-48" />
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-12"><div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full" /></div>
      ) : filtered.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12 text-muted-foreground">
            <ShoppingCart size={36} className="mb-3 opacity-30" />
            <p className="text-sm">Aucune commande trouvée</p>
            <Button className="mt-4" size="sm" onClick={() => navigate("/dashboard/order")}>Passer une commande</Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {filtered.map(order => {
            const s = STATUS[order.status as keyof typeof STATUS] || { label: order.status, className: "bg-gray-100 text-gray-700" };
            return (
              <Card key={order.id}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="font-medium text-sm">{order.service_name}</p>
                        <span className={`text-xs px-2 py-0.5 rounded-full border font-medium ${s.className}`}>{s.label}</span>
                      </div>
                      <p className="text-xs text-muted-foreground mt-1 truncate">
                        {order.service_category} · {order.quantity.toLocaleString()} unités
                      </p>
                      <p className="text-xs text-muted-foreground truncate mt-0.5">🔗 {order.link}</p>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="font-bold text-sm">{Number(order.price).toLocaleString()} FCFA</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {new Date(order.created_at).toLocaleDateString("fr-FR", { day: "2-digit", month: "short", year: "numeric" })}
                      </p>
                    </div>
                  </div>
                  {order.external_order_id && (
                    <p className="text-xs text-muted-foreground mt-2">ID SMM: {order.external_order_id}</p>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
