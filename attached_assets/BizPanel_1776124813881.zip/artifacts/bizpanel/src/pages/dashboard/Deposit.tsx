import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { initiatePayment } from "@/lib/soleaspay";
import { toast } from "sonner";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Wallet, Smartphone, Shield, Zap } from "lucide-react";

const AMOUNTS = [1000, 2000, 5000, 10000, 20000, 50000];

export default function Deposit() {
  const { user, profile } = useAuth();
  const [amount, setAmount] = useState(0);
  const [custom, setCustom] = useState("");
  const [loading, setLoading] = useState(false);

  const finalAmount = custom ? Number(custom) : amount;

  const handleDeposit = async () => {
    if (finalAmount < 500) { toast.error("Montant minimum : 500 FCFA"); return; }
    if (!user) return;

    setLoading(true);
    try {
      const { data: settings } = await supabase.from("settings").select("key, value");
      const cfg = {
        merchant_id: settings?.find(s => s.key === "soleaspay_merchant_id")?.value || "",
        api_key: settings?.find(s => s.key === "soleaspay_api_key")?.value || "",
        callback_url: settings?.find(s => s.key === "soleaspay_callback_url")?.value || "",
      };

      const { data: payment } = await supabase.from("payments").insert({
        user_id: user.id,
        amount: finalAmount,
        method: "soleaspay",
        status: "pending",
      }).select().single();

      if (cfg.merchant_id && cfg.api_key && cfg.merchant_id !== "YOUR_MERCHANT_ID") {
        const result = await initiatePayment(cfg, finalAmount, user.id, `Rechargement BizPanel #${payment?.id?.slice(0, 8)}`);
        if (result.success && result.payment_url) {
          if (payment?.id) {
            await supabase.from("payments").update({ reference: result.reference }).eq("id", payment.id);
          }
          window.location.href = result.payment_url;
        } else {
          toast.error(result.message || "Erreur SoleasPay");
        }
      } else {
        await supabase.from("profiles").update({
          balance: Number(profile?.balance || 0) + finalAmount
        }).eq("user_id", user.id);
        await supabase.from("payments").update({ status: "completed" }).eq("id", payment?.id);
        toast.success(`✅ ${finalAmount.toLocaleString()} FCFA crédités (mode démo). Configurez SoleasPay dans l'admin pour activer les vrais paiements.`);
      }
    } catch (e: any) {
      toast.error(e.message || "Erreur lors du paiement");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 max-w-2xl">
      <div>
        <h2 className="text-xl font-bold font-heading">Recharger mon solde</h2>
        <p className="text-sm text-muted-foreground">Ajoutez des fonds via Mobile Money (Orange, MTN, etc.)</p>
      </div>

      <Card className="bg-gradient-to-r from-primary to-accent text-white">
        <CardContent className="p-5 flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center">
            <Wallet size={22} />
          </div>
          <div>
            <p className="text-sm opacity-80">Solde actuel</p>
            <p className="text-3xl font-bold">{Number(profile?.balance || 0).toLocaleString()} FCFA</p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-base">Choisir un montant</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-3 gap-3">
            {AMOUNTS.map(a => (
              <button
                key={a}
                onClick={() => { setAmount(a); setCustom(""); }}
                className={`py-3 rounded-lg border text-sm font-semibold transition-colors ${
                  amount === a && !custom ? "bg-primary text-primary-foreground border-primary" : "border-border hover:border-primary"
                }`}
              >
                {a.toLocaleString()} F
              </button>
            ))}
          </div>
          <div>
            <Label htmlFor="custom">Ou entrez un montant personnalisé</Label>
            <Input
              id="custom"
              type="number"
              placeholder="Ex: 15000"
              value={custom}
              onChange={e => { setCustom(e.target.value); setAmount(0); }}
              className="mt-1"
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-5 space-y-4">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Montant à recharger</span>
            <span className="font-bold">{finalAmount.toLocaleString()} FCFA</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Frais de traitement</span>
            <span className="text-green-600 font-medium">Gratuit</span>
          </div>
          <div className="border-t pt-3 flex justify-between">
            <span className="font-medium">Nouveau solde</span>
            <span className="font-bold text-primary">{(Number(profile?.balance || 0) + finalAmount).toLocaleString()} FCFA</span>
          </div>

          <Button className="w-full h-12" onClick={handleDeposit} disabled={loading || finalAmount < 500}>
            <Smartphone size={16} className="mr-2" />
            {loading ? "Traitement..." : `Payer ${finalAmount.toLocaleString()} FCFA via Mobile Money`}
          </Button>

          <div className="flex items-center gap-4 justify-center text-xs text-muted-foreground">
            <span className="flex items-center gap-1"><Shield size={12} /> Paiement sécurisé</span>
            <span className="flex items-center gap-1"><Zap size={12} /> Crédit instantané</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
