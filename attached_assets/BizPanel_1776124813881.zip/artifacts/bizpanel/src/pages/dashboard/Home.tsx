import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Wallet, ShoppingCart, Clock, CheckCircle, TrendingUp,
  Instagram, Youtube, Facebook, Share2, Send, Plus
} from "lucide-react";

const PLATFORMS = [
  { name: "Instagram", icon: Instagram, color: "from-pink-500 to-purple-600", href: "/dashboard/order?cat=Instagram" },
  { name: "TikTok", icon: Share2, color: "from-gray-800 to-gray-950", href: "/dashboard/order?cat=TikTok" },
  { name: "Facebook", icon: Facebook, color: "from-blue-600 to-blue-700", href: "/dashboard/order?cat=Facebook" },
  { name: "YouTube", icon: Youtube, color: "from-red-500 to-red-700", href: "/dashboard/order?cat=YouTube" },
  { name: "Telegram", icon: Send, color: "from-sky-500 to-sky-600", href: "/dashboard/order?cat=Telegram" },
];

interface Stats {
  total: number;
  pending: number;
  processing: number;
  completed: number;
  cancelled: number;
}

interface RecentOrder {
  id: string;
  service_name: string;
  service_category: string;
  quantity: number;
  price: number;
  status: string;
  created_at: string;
}

const statusLabel: Record<string, { label: string; color: string }> = {
  pending: { label: "En attente", color: "bg-yellow-100 text-yellow-800" },
  processing: { label: "En cours", color: "bg-blue-100 text-blue-800" },
  completed: { label: "Terminé", color: "bg-green-100 text-green-800" },
  cancelled: { label: "Annulé", color: "bg-red-100 text-red-800" },
};

export default function DashboardHome() {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState<Stats>({ total: 0, pending: 0, processing: 0, completed: 0, cancelled: 0 });
  const [recentOrders, setRecentOrders] = useState<RecentOrder[]>([]);

  useEffect(() => {
    if (!user) return;
    const load = async () => {
      const { data: orders } = await supabase
        .from("orders").select("*").eq("user_id", user.id).order("created_at", { ascending: false }).limit(5);
      if (orders) {
        setRecentOrders(orders);
        const { data: allOrders } = await supabase.from("orders").select("status").eq("user_id", user.id);
        if (allOrders) {
          setStats({
            total: allOrders.length,
            pending: allOrders.filter(o => o.status === "pending").length,
            processing: allOrders.filter(o => o.status === "processing").length,
            completed: allOrders.filter(o => o.status === "completed").length,
            cancelled: allOrders.filter(o => o.status === "cancelled").length,
          });
        }
      }
    };
    load();
  }, [user]);

  const statCards = [
    { label: "Solde disponible", value: `${Number(profile?.balance || 0).toLocaleString()} FCFA`, icon: Wallet, color: "text-primary", bg: "bg-primary/10" },
    { label: "Total commandes", value: stats.total, icon: ShoppingCart, color: "text-accent", bg: "bg-accent/10" },
    { label: "En cours", value: stats.pending + stats.processing, icon: Clock, color: "text-yellow-600", bg: "bg-yellow-50" },
    { label: "Terminées", value: stats.completed, icon: CheckCircle, color: "text-green-600", bg: "bg-green-50" },
    { label: "Gains affiliation", value: `${Number(profile?.affiliate_earnings || 0).toLocaleString()} FCFA`, icon: TrendingUp, color: "text-purple-600", bg: "bg-purple-50" },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {statCards.map((stat) => (
          <Card key={stat.label}>
            <CardContent className="p-4">
              <div className={`w-9 h-9 rounded-lg ${stat.bg} flex items-center justify-center mb-3`}>
                <stat.icon size={18} className={stat.color} />
              </div>
              <p className="text-xs text-muted-foreground mb-1">{stat.label}</p>
              <p className="text-lg font-bold font-heading">{stat.value}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="border-primary/20 bg-primary/5">
          <CardContent className="p-5 flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
              <Plus size={22} className="text-primary" />
            </div>
            <div>
              <p className="font-semibold">Passer une commande</p>
              <p className="text-sm text-muted-foreground">Choisissez un service et boostez votre présence</p>
            </div>
            <Button className="ml-auto" onClick={() => navigate("/dashboard/order")}>Commander</Button>
          </CardContent>
        </Card>
        <Card className="border-accent/20 bg-accent/5">
          <CardContent className="p-5 flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-accent/20 flex items-center justify-center">
              <Wallet size={22} className="text-accent" />
            </div>
            <div>
              <p className="font-semibold">Recharger le solde</p>
              <p className="text-sm text-muted-foreground">Ajoutez des fonds via Mobile Money</p>
            </div>
            <Button variant="secondary" className="ml-auto" onClick={() => navigate("/dashboard/deposit")}>Recharger</Button>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">Choisir une plateforme</CardTitle></CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 md:grid-cols-5 gap-3">
            {PLATFORMS.map((p) => (
              <button
                key={p.name}
                onClick={() => navigate(p.href)}
                className={`bg-gradient-to-br ${p.color} text-white rounded-xl p-4 flex flex-col items-center gap-2 hover:opacity-90 transition-opacity`}
              >
                <p.icon size={22} />
                <span className="text-xs font-medium">{p.name}</span>
              </button>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-base">Commandes récentes</CardTitle>
          <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard/orders")}>Voir tout</Button>
        </CardHeader>
        <CardContent>
          {recentOrders.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <ShoppingCart size={32} className="mx-auto mb-2 opacity-30" />
              <p className="text-sm">Aucune commande pour l'instant</p>
              <Button className="mt-3" size="sm" onClick={() => navigate("/dashboard/order")}>Passer ma première commande</Button>
            </div>
          ) : (
            <div className="space-y-3">
              {recentOrders.map((order) => {
                const s = statusLabel[order.status] || { label: order.status, color: "bg-gray-100 text-gray-700" };
                return (
                  <div key={order.id} className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{order.service_name}</p>
                      <p className="text-xs text-muted-foreground">{order.service_category} · {order.quantity.toLocaleString()} unités</p>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="text-sm font-semibold">{Number(order.price).toLocaleString()} FCFA</p>
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${s.color}`}>{s.label}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
