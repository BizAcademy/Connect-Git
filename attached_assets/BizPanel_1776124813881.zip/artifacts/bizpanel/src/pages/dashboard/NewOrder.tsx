import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ShoppingCart, Search, Clock } from "lucide-react";

const CATEGORIES = ["Instagram", "TikTok", "Facebook", "YouTube", "Telegram"];

interface Service {
  id: string;
  category: string;
  name: string;
  description: string;
  price_per_1000: number;
  min_quantity: number;
  max_quantity: number;
  delivery_time: string;
  external_service_id: string;
}

export default function NewOrder() {
  const { user, profile, refreshProfile } = useAuth();
  const [searchParams] = useSearchParams();
  const [services, setServices] = useState<Service[]>([]);
  const [filtered, setFiltered] = useState<Service[]>([]);
  const [selectedCat, setSelectedCat] = useState(searchParams.get("cat") || "Instagram");
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [search, setSearch] = useState("");
  const [link, setLink] = useState("");
  const [quantity, setQuantity] = useState(0);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    supabase.from("services").select("*").eq("is_active", true).order("sort_order")
      .then(({ data }) => { if (data) setServices(data); });
  }, []);

  useEffect(() => {
    let list = services.filter(s => s.category === selectedCat);
    if (search) list = list.filter(s => s.name.toLowerCase().includes(search.toLowerCase()));
    setFiltered(list);
    setSelectedService(null);
  }, [selectedCat, services, search]);

  useEffect(() => {
    if (selectedService) setQuantity(selectedService.min_quantity);
  }, [selectedService]);

  const totalPrice = selectedService
    ? Math.ceil((quantity / 1000) * selectedService.price_per_1000)
    : 0;

  const handleOrder = async () => {
    if (!user || !selectedService) return;
    if (!link.trim()) { toast.error("Veuillez entrer un lien"); return; }
    if (quantity < selectedService.min_quantity || quantity > selectedService.max_quantity) {
      toast.error(`Quantité entre ${selectedService.min_quantity} et ${selectedService.max_quantity}`);
      return;
    }
    const balance = Number(profile?.balance || 0);
    if (totalPrice > balance) {
      toast.error(`Solde insuffisant. Vous avez ${balance.toLocaleString()} FCFA, il faut ${totalPrice.toLocaleString()} FCFA`);
      return;
    }

    setLoading(true);
    try {
      const { error: balErr } = await supabase
        .from("profiles")
        .update({ balance: balance - totalPrice })
        .eq("user_id", user.id);
      if (balErr) throw balErr;

      const { error: ordErr } = await supabase.from("orders").insert({
        user_id: user.id,
        service_name: selectedService.name,
        service_category: selectedService.category,
        link: link.trim(),
        quantity,
        price: totalPrice,
        status: "pending",
        external_order_id: null,
      });
      if (ordErr) throw ordErr;

      await refreshProfile();
      toast.success("Commande passée avec succès !");
      setLink("");
      setQuantity(selectedService.min_quantity);
      setSelectedService(null);
    } catch (e: any) {
      toast.error(e.message || "Erreur lors de la commande");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <h2 className="text-xl font-bold font-heading">Nouvelle commande</h2>
        <p className="text-sm text-muted-foreground">Choisissez un service et entrez les détails</p>
      </div>

      <div className="flex flex-wrap gap-2">
        {CATEGORIES.map(cat => (
          <button
            key={cat}
            onClick={() => setSelectedCat(cat)}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors border ${
              selectedCat === cat
                ? "bg-primary text-primary-foreground border-primary"
                : "border-border text-muted-foreground hover:border-primary hover:text-primary"
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-3">
          <div className="relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Rechercher un service..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pl-9"
            />
          </div>
          <div className="space-y-2 max-h-[420px] overflow-y-auto pr-1">
            {filtered.length === 0 && (
              <p className="text-center text-sm text-muted-foreground py-8">Aucun service disponible</p>
            )}
            {filtered.map(service => (
              <button
                key={service.id}
                onClick={() => setSelectedService(service)}
                className={`w-full text-left p-3 rounded-lg border transition-colors ${
                  selectedService?.id === service.id
                    ? "border-primary bg-primary/5"
                    : "border-border hover:border-primary/50"
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <p className="text-sm font-medium leading-snug">{service.name}</p>
                  <span className="text-xs font-bold text-primary whitespace-nowrap">{service.price_per_1000.toLocaleString()} FCFA/1000</span>
                </div>
                <div className="flex gap-3 mt-1.5">
                  <span className="text-xs text-muted-foreground flex items-center gap-1">
                    <Clock size={11} /> {service.delivery_time}
                  </span>
                  <span className="text-xs text-muted-foreground">
                    Min: {service.min_quantity.toLocaleString()} · Max: {service.max_quantity.toLocaleString()}
                  </span>
                </div>
              </button>
            ))}
          </div>
        </div>

        <div>
          {!selectedService ? (
            <Card className="h-full">
              <CardContent className="flex flex-col items-center justify-center h-full py-12 text-muted-foreground">
                <ShoppingCart size={36} className="mb-3 opacity-30" />
                <p className="text-sm">Sélectionnez un service pour commander</p>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">{selectedService.name}</CardTitle>
                {selectedService.description && (
                  <p className="text-sm text-muted-foreground">{selectedService.description}</p>
                )}
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-3 gap-3 text-center text-sm">
                  <div className="bg-muted rounded-lg p-2">
                    <p className="text-xs text-muted-foreground">Prix/1000</p>
                    <p className="font-bold text-primary">{selectedService.price_per_1000.toLocaleString()} F</p>
                  </div>
                  <div className="bg-muted rounded-lg p-2">
                    <p className="text-xs text-muted-foreground">Min</p>
                    <p className="font-bold">{selectedService.min_quantity.toLocaleString()}</p>
                  </div>
                  <div className="bg-muted rounded-lg p-2">
                    <p className="text-xs text-muted-foreground">Livraison</p>
                    <p className="font-bold">{selectedService.delivery_time}</p>
                  </div>
                </div>

                <div>
                  <Label htmlFor="link">Lien (post ou profil)</Label>
                  <Input
                    id="link"
                    placeholder="https://instagram.com/..."
                    value={link}
                    onChange={e => setLink(e.target.value)}
                    className="mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="qty">Quantité ({selectedService.min_quantity.toLocaleString()} – {selectedService.max_quantity.toLocaleString()})</Label>
                  <Input
                    id="qty"
                    type="number"
                    min={selectedService.min_quantity}
                    max={selectedService.max_quantity}
                    value={quantity}
                    onChange={e => setQuantity(Number(e.target.value))}
                    className="mt-1"
                  />
                </div>

                <div className="bg-muted rounded-lg p-4 flex items-center justify-between">
                  <div>
                    <p className="text-xs text-muted-foreground">Total à payer</p>
                    <p className="text-2xl font-bold text-primary">{totalPrice.toLocaleString()} FCFA</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-muted-foreground">Votre solde</p>
                    <p className={`text-sm font-semibold ${totalPrice > Number(profile?.balance) ? "text-red-500" : "text-green-600"}`}>
                      {Number(profile?.balance || 0).toLocaleString()} FCFA
                    </p>
                  </div>
                </div>

                <Button
                  className="w-full"
                  onClick={handleOrder}
                  disabled={loading || totalPrice === 0 || !link.trim()}
                >
                  {loading ? "Traitement..." : "Confirmer la commande"}
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
