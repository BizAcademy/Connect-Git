import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { CreditCard, CheckCircle, Clock, XCircle } from "lucide-react";

const STATUS = {
  pending: { label: "En attente", icon: Clock, className: "text-yellow-600 bg-yellow-50" },
  completed: { label: "Validé", icon: CheckCircle, className: "text-green-600 bg-green-50" },
  rejected: { label: "Rejeté", icon: XCircle, className: "text-red-600 bg-red-50" },
};

interface Payment {
  id: string;
  amount: number;
  method: string;
  status: string;
  reference: string | null;
  created_at: string;
}

export default function PaymentHistory() {
  const { user } = useAuth();
  const [payments, setPayments] = useState<Payment[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    supabase.from("payments").select("*").eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .then(({ data }) => { setPayments(data || []); setLoading(false); });
  }, [user]);

  const total = payments.filter(p => p.status === "completed").reduce((acc, p) => acc + Number(p.amount), 0);

  return (
    <div className="space-y-5 max-w-3xl">
      <div>
        <h2 className="text-xl font-bold font-heading">Historique des paiements</h2>
        <p className="text-sm text-muted-foreground">Total rechargé : {total.toLocaleString()} FCFA</p>
      </div>

      {loading ? (
        <div className="flex justify-center py-12"><div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full" /></div>
      ) : payments.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12 text-muted-foreground">
            <CreditCard size={36} className="mb-3 opacity-30" />
            <p className="text-sm">Aucun paiement enregistré</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {payments.map(payment => {
            const s = STATUS[payment.status as keyof typeof STATUS] || STATUS.pending;
            const Icon = s.icon;
            return (
              <Card key={payment.id}>
                <CardContent className="p-4 flex items-center gap-4">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${s.className}`}>
                    <Icon size={18} />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-sm">{Number(payment.amount).toLocaleString()} FCFA</p>
                    <p className="text-xs text-muted-foreground">
                      {payment.method.toUpperCase()} · {new Date(payment.created_at).toLocaleDateString("fr-FR", { day: "2-digit", month: "long", year: "numeric" })}
                    </p>
                    {payment.reference && <p className="text-xs text-muted-foreground">Réf: {payment.reference}</p>}
                  </div>
                  <span className={`text-xs px-2 py-1 rounded-full font-medium ${s.className}`}>{s.label}</span>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
