export interface SoleasPayConfig {
  merchant_id: string;
  api_key: string;
  callback_url: string;
}

export interface PaymentInitResponse {
  success: boolean;
  payment_url?: string;
  reference?: string;
  message?: string;
}

export interface PaymentVerifyResponse {
  success: boolean;
  status: 'pending' | 'completed' | 'failed';
  amount?: number;
  reference?: string;
}

export async function initiatePayment(
  config: SoleasPayConfig,
  amount: number,
  user_id: string,
  description: string = 'Rechargement BizPanel'
): Promise<PaymentInitResponse> {
  try {
    const response = await fetch('https://soleaspay.com/api/v1/payment/initiate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${config.api_key}`,
      },
      body: JSON.stringify({
        merchant_id: config.merchant_id,
        amount,
        currency: 'XAF',
        description,
        reference: `BPANEL-${user_id.slice(0, 8)}-${Date.now()}`,
        callback_url: config.callback_url,
        return_url: `${window.location.origin}/dashboard/payments`,
        metadata: { user_id },
      }),
    });
    const data = await response.json();
    return {
      success: response.ok,
      payment_url: data.payment_url,
      reference: data.reference,
      message: data.message,
    };
  } catch {
    return { success: false, message: 'Erreur de connexion à SoleasPay' };
  }
}

export async function verifyPayment(
  config: SoleasPayConfig,
  reference: string
): Promise<PaymentVerifyResponse> {
  try {
    const response = await fetch(`https://soleaspay.com/api/v1/payment/verify/${reference}`, {
      headers: { 'Authorization': `Bearer ${config.api_key}` },
    });
    const data = await response.json();
    return {
      success: response.ok,
      status: data.status || 'pending',
      amount: data.amount,
      reference: data.reference,
    };
  } catch {
    return { success: false, status: 'pending' };
  }
}
